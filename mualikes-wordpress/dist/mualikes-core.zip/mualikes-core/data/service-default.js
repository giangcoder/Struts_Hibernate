var cancellationFee = 5000,
            maxGuaranteeCanceled = 3,
            ajaxData = function(data) {
                data.order_id = $('body').data('orders');
            },
            columns = [{
                    data: 'id',
                    name: 'id',
                    title: '#'
                },
                {
                    data: 'uid',
                    name: 'uid',
                    title: "Uid"
                },
                {
                    data: 'server',
                    name: 'server',
                    title: "Server",
                    class: 'text-left'
                },
                {
                    data: 'content',
                    name: 'content',
                    title: "Nội dung",
                    style: 'width: 178.6px;'
                },
                {
                    data: 'note',
                    name: 'note',
                    title: "Ghi chú"
                },
                {
                    data: 'admin_note',
                    name: 'admin_note',
                    title: "Admin note"
                },
                {
                    data: 'amount',
                    name: 'amount',
                    title: "Số tiền"
                },
                {
                    data: 'count',
                    name: 'count',
                    title: "Số lượng"
                },
                {
                    data: 'original',
                    name: 'original',
                    title: "Bắt đầu"
                },
                {
                    data: 'present',
                    name: 'present',
                    title: "Đã chạy"
                },
                {
                    data: 'created',
                    name: 'created',
                    title: "Thời gian"
                },
                {
                    data: 'status',
                    name: 'status',
                    title: "Trạng thái"
                },
                {
                    data: 'action',
                    name: 'action',
                    searchable: false,
                    orderable: false,
                    title: "Hành động"
                },
                {
                    data: 'detail',
                    name: 'detail',
                    title: "Xem chi tiết"
                },
            ];
            $(document).ready(function() { 
                $('.popup').trigger('click');                      
                $(".bang-gia-facebook, .bang-gia-tiktok, .bang-gia-youtube, .bang-gia-twitter, .bang-gia-instagram, .bang-gia-telegram, .bang-gia-threads, .bang-gia-shopee,.bang-gia-khac").each( async function(index, element) {
                    const {
                        status,
                        message
                    } = await $.post('/server/graph-api?action=bang-gia', {
                        'service' : $(this).attr('class')
                    });

                    if (status) {
                        var html = message;
                        $(this).html(html);
                    }
                });
                
            function explode_by(begin, end, data) {
                try {
                    data = data.split(begin);
                    data = data[1].split(end);
                    return data[0];
                } catch (ex) {
                    return "";
                }
            }

            function formatLink(link) {
                link = link.toString();
                if (!link.includes('?') || link.match(/\?fbid|story_fbid|watch\//) || link.match(/story_fbid|story\.php/)) return link;
                return link.split("?")[0];
            }

            async function getPostUid(input, silent = true) {
                let data = formatLink(input);
                if (data.match(/(^[\d_]+$|^pfbid\w+)/)) return [true, data];

                let uid;
                if (data.match(/facebook\.com|fb\.watch/)) {
                    let info;
                    if (data.includes("/posts/") || data.includes("/videos/")) {
                        info = data.split("/");
                        uid = info[info.length - 1];
                        if (uid.includes("?")) uid = uid.split("?")[0];
                        if (!uid) uid = info[info.length - 2];
                    } else if (data.includes("fbid=")) {
                        let match = data.match(/fbid=([\d\w]+)/);
                        if (match) uid = match[1];
                    } else if (data.includes("story_fbid=")) {
                        uid = explode_by("story_fbid=", "&", data);
                    } else if (data.includes("/photos/")) {
                        info = data.split("/");
                        uid = info[info.length - 2];
                    } else if (data.match(/\/permalink\/([0-9]+)/)) {
                        uid = data.match(/\/permalink\/([0-9]+)/)[1];
                    } else if (data.match(/watch\/live\/\?v=/)) {
                        uid = data.match(/watch\/live\/\?v=([0-9]+)/)[1];
                    } else if (data.match(/watch\/\?v=/)) {
                        uid = data.match(/watch\/\?v=([0-9]+)/)[1];
                    } else if (data.match(/watch\/live/) && data.match(/v=\d+/)) {
                        uid = data.match(/v=(\d+)/)[1];
                    } else if (data.match(/\/stories\//)) {
                        uid = data.split('?')[0];
                    } else if (data.match(/\/reel\//)) {
                        let match1 = data.match(/reel\/(\d+)/);
                        if (match1) uid = match1[1];
                    } else if (data.match(/\/events\//)) {
                        let match1 = data.match(/events\/(\d+)/);
                        if (match1) uid = match1[1];
                    } else if (data.match(/\?id=\d+/)) {
                        uid = data.match(/\?id=(\d+)/)[1];
                    } else if (data.match(/multi_permalinks=\d+/)) {
                        uid = data.match(/multi_permalinks=([0-9]+)/)[1];
                    } else if (data.match(/(fb\.watch|facebook\.com\/share\/)/)) {
                        let  action = 'get-link-facebook';
                        $('#uid').prop('disabled', true).val('Đang lấy uid, vui lòng chờ!');
                        const {
                            status,
                            message
                        } = await $.post('/server/graph-api?action=' + action, {
                            post_link: data
                        });
                        $('#uid').prop('disabled', false);
                        if (status) {
                            return [true, message];
                        }
                    }
                }

                if (!uid) return [false, 'Không nhận ra uid'];

                return [true, uid];
            }

            async function getCommentLink(input) {
                // Neu da dung dinh dang
                if (input.match(/\w+_\d+/)) return [true, input];

                // output should be {post_id}_{comment_id}
                let [success, post_id] = await getPostUid(input, false);
                if (success) {
                    let match = input.match(/reply_comment_id=([0-9]+)/);
                    if (!match) match = input.match(/comment_id=([0-9]+)/);
                    if (match) return [true, post_id + '_' + match[1]];
                }

                return [false, 'Không nhận dạng được link!'];
            }

            $('#comment_link').on("change", async function() {
                let [success, data] = await getCommentLink($(this).val());
                if (success) {
                    $('#originalLink').val($(this).val());
                    $(this).val(data);
                    toastr.success('Lấy uid thành công');
                    _this.prop('disabled', false).val(message);
                }
            });
            
            $(document).on("change", "#uid", async function() {
                let inputText = $(this).val();
                if ($('#url').length) $('#url').val(inputText);
    
                let [success, uid] = await getPostUid(inputText, false);
    
                if (success) {
                    $("#uid").val(uid);
                    $('#originalLink').val(inputText);
                    if (typeof toastr !== "undefined") toastr.success("Cập nhật uid thành công");
                } else {
                    if (typeof toastr !== "undefined" && inputText) toastr.error(uid || "Không nhận ra uid");
                }
            });

    });